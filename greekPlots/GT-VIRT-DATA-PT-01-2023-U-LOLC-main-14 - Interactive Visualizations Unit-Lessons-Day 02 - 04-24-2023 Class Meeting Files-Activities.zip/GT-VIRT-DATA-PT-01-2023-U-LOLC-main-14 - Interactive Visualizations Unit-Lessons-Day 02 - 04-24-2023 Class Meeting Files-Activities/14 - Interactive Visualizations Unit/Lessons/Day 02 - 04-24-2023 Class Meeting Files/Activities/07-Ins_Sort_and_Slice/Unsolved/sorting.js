// Sort the array in descending order
let numArray = [1, 2, 3];


// Sort the array in ascending order
let numArray2 = [3, 2, 1];


// Sort the array in ascending order, using an arrow function
let numArray3 = [3, 2, 1];


// Reverse the array
let numArray4 = [1, 2, 3];