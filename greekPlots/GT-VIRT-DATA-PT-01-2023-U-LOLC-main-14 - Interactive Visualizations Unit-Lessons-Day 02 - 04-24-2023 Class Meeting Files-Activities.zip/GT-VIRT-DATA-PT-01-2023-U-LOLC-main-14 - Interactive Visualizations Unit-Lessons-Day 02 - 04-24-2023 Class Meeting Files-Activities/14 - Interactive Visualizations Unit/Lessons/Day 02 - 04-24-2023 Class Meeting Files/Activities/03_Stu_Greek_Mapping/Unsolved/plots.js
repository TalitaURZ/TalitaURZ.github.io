console.log(data);

// Trace for the Greek Data


// Data trace array


// Apply the group barmode to the layout


// Render the plot to the div tag with id "plot"
