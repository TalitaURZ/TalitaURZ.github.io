// Sort the data by Greek search results descending


// Slice the first 10 objects for plotting


// Reverse the array to accommodate Plotly's defaults


// Trace for the Greek Data


// Data array


// Apply a title to the layout


// Render the plot to the div tag with id "plot"